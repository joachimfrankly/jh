  
  class CartService {
    static getItems(timestamp) {
      return new Promise((resolve, reject) => {
        jQuery.getJSON(`/cart.js`)
        .then(res => {
          resolve(res.items)
        })
      });
    }
    
    static get(timestamp) {
      return new Promise((resolve, reject) => {
        jQuery.ajax({
          type: 'GET',
          url: `/cart?view=drawer&timestamp=${timestamp}&source=custom`,
  
          success: function(msg) {
            resolve(msg);
          },
          error: function() {
            alert(
                'Oops! Something went wrong. Please try to add your product again. If this message persists, the item may not be available.');
            reject({message: 'Oops!'});
          },
        });
      });
    }
  
    static add(id) {
      return new Promise((resolve, reject) => {
        jQuery.ajax({
          type: 'POST',
          url: '/cart/add.js',
          data: {
            quantity: 1,
            id: id,
          },
          dataType: 'json',
          success: function(data) {
            resolve(data);
          },
          error: function() {
            alert(
                'Oops! Something went wrong. Please try to add your product again. If this message persists, the item may not be available.');
            reject({message: 'Oops!'});
          },
        });
      });
    }
  }
  
  class ProductService {
    static getBySelector(product_url) {
  
      return new Promise((resolve, reject) => {
        jQuery.getJSON(product_url + '.js', function(product) {
          resolve(product);
        });
      });
    }
  }
  
  const generateUpsellItemCheckedId = (id) => `UpsellItem_Checked${id}`;
  const generateUpsellItemSelectorId = (id) => `UpsellItem_Selector${id}`;

function addtocart_custom(selectedProductId, product_url) {
   const loadingBar = $('.LoadingBar')
  
    loadingBar.addClass('is-visible');
    loadingBar.css('width', '40%');
  
  const addToCartButton = $('#VirtualTryOn__Button');
  addToCartButton.attr('disabled');
  
  
  // -- We have the product url now, and declared a variable for the id which we will set later
  // -- now we are getting the products JSON object, which we need to push to the cart
  
    ProductService.getBySelector(product_url).then(product => {
      if(!product.variants || !Array.isArray(product.variants) || product.variants.length === 0)
      {
        product = product.product;
        
        if(!product.variants || !Array.isArray(product.variants) || product.variants.length === 0){
          console.log('failed');
          return;
        }
      }
  
      const variantId = product.variants[1] ? product.variants[1].id : product.variants[0].id ;
      CartService.add(variantId).then(cart => {
        loadingBar.css('width', '100%');
        
        if (cart) {
          CartService.get(Date.now()).then(cart => {
            
             loadingBar.css('width', '120%');
            
            const cartElement = $($.parseHTML(cart));
            const drawerElement = cartElement.find('form');
  
            const drawerHtml = drawerElement.html();
  
            const cartFormElement = $('#sidebar-cart').find('form');
            cartFormElement.html(drawerHtml);
            loadingBar.addClass('is-finished');
            
            /*Send custom event*/
            addToCartButton.removeAttr('disabled');
            // We simply trigger an event so the mini-cart can re-render
            document.dispatchEvent(new CustomEvent('product:added', {detail: {quantity: 1}}));
            
          });
  
        }
      });
    });
  }