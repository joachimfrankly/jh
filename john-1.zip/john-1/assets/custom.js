

function scrollToReviews(){

  $(".on_product_review").click(function() {
      $('html,body').animate({
          scrollTop: $("#shc").offset().top- 100 },
          'slow');
  });

  }

function openChat(){
$( "li[t='LIVE CHAT']" ).on('click', function(){
tidioChatApi.open();
});


}

function setSkuFrame(sku, id, productUrl, stringifiedProduct){
	fitmixInstance.setFrame(sku)

    // try{
    //   	const parsedObj = JSON.parse(stringifiedProduct);
    // 	$('.VirtualTryOn__ButtonProductName').text(`- ${parsedObj.name}`);
    // }catch(e){
    //   console.log(e);
    // }

  $('#VirtualTryOn__ViewMoreButton').unbind( "click" );

  $('#VirtualTryOn__ViewMoreButton').bind('click', function(){
      window.location.href=productUrl;
    });

    $('#VirtualTryOn__Button').unbind( "click" );
    $('#VirtualTryOn__Button').bind('click', function(){
      addtocart_custom(id, productUrl);
    });
}



function discount(){

$(".cart_one_for_one #oneforone").change(function() {
    if(this.checked) {
       $('.cart_one_for_one #discount').val('JOIN ONE FOR ONE');
      $('.after_dc').toggleClass("is_visable");
        $('.before_dc').toggleClass("crossed");
    }else {
      $('.cart_one_for_one #discount').val('');
           $('.after_dc').toggleClass("is_visable");
        $('.before_dc').toggleClass("crossed");
    }
});

}


function animateReviewsBars(){
$('#filler_1').delay(700).queue(function () {
        $(this).css('width', '92%')
    });
$('#filler_2').delay(700).queue(function () {
        $(this).css('width', '8%')
    });/*
$('#filler_3').delay(700).queue(function () {
        $(this).css('width', '6%')
    });
$('#filler_4').delay(700).queue(function () {
        $(this).css('width', '2%')
    });
$('#filler_5').delay(700).queue(function () {
        $(this).css('width', '1%')
    });*/
}




function initializeMainMenuImageToggle(title){

  const elements = $(`#${title}__Linklist`).find('.Linklist__Item');
  elements.each((i,val) => {
    const el = $(val);
    const attrTitle = el.attr('t');

    console.log(title, attrTitle);

    el.hover( function(){ $(`#${attrTitle}__LinklistItemImage`).toggleClass("MainMenu__LinkImage--show");},
			function(){$(`#${attrTitle}__LinklistItemImage`).toggleClass("MainMenu__LinkImage--show");})
	});
}

function toggleSustain(){
  $('.sustain_qoute:first').addClass('activato');
  $('a.sustain:first').addClass('is_selected');
 $(".sustain").click(function () {
   event.preventDefault();
        var addressValue = $(this).attr("div");
       $('.is_selected').removeClass('is_selected')
   $(this).addClass('is_selected');



    $('.activato').removeClass('activato')
        // add active class to clicked element
        $('#'+addressValue).addClass('activato');
  });
}


function setupMeniuOffset(){
	const elements = $('.HorizontalList__Item');

  if(elements.length > 0){
    elements.each((i,v) => {
      const el = $(v);
      	el.find('.Linklist__Item').css('padding-left', el.offset().left);
    });
  }
}


function setupGetInspredGrid(){
  const el = $("#Grid__GetInspired");
  if(el.lengtth == 0){
  	return;
  }

  const items = $(".Grid__GetInspiredItem");
  const lastItem = items.last();
  if(items.length == 0){
  	return;
  }

  const itemWidth = lastItem.width();
  let maxItemHeight = lastItem.height();
  const numberOfCols = Math.floor($(window).width() / itemWidth);
  const numberOfRows = Math.floor(items.length / numberOfCols);

  let isSmall = false;
  let rowTemp = 0;
  let maxHeight = 0;

  items.each((i,value) => {
    let rowHeiht = 0;

    const element =  $(this);
    const elementHeight = element.height();

    const col = i%numberOfCols;
    const row = Math.floor(i/numberOfCols);


    /*calculate height of row, global max item height */
    if(row > 0){

      for(let i = 1; i <= row; i++){
        const preParalelIndex = col+(i-1)*numberOfCols;
        const paralelEl = $(items[preParalelIndex])
        rowHeiht = rowHeiht + paralelEl.height();

        maxItemHeight = maxItemHeight < paralelEl.height() ? paralelEl.height() : maxItemHeight;
      }

      maxHeight = maxHeight < rowHeiht ? rowHeiht : maxHeight;
    }

    /* initialize is small flag for that row */
    if(row !== rowTemp){
      rowTemp = row;

      isSmall = row%2 != 0;
    }

    const left = col*itemWidth;
    const top = rowHeiht.toFixed(2);


    if(top !== 'NaN' ){

      const isHidden = false; //row > numberOfRows-2 && col%2 == 0; //hidden last two blog posts, owerflow problem

      if(!isHidden){
        //const padding = isSmall ? `${80 + Math.random()*30}%` : '130%';//`${100 + Math.random()*30}%`;
        const padding = isSmall ? `${90 + Math.random()*20}%` : `${110 + Math.random()*40}%`;


        $(value).find('.ArticleItem__ImageWrapper').css('padding-top', padding);

        const item = $(value);
        item.css({"left": `${left}px`, "top": `${top}px`});
        item.addClass('Grid__GetInspiredItem--show');
        isSmall = !isSmall;
      }
    }
  });

  el.css({"width": `${numberOfCols*itemWidth}px`, "height": `${maxHeight + maxItemHeight}px`, 'margin': 'auto'});

}



function setProductH(){
   $('.Product__Slideshow > .flickity-viewport > .flickity-slider').each(function() {
var setWidth = $(this).find('img').width();
        $(this).width(setWidth);
     console.log(setWidth);
    });

  if(window.f && window.f.flickityInstance){
  //window.f.flickityInstance.resize();
  }

}

function isMobile(){
  const width = $(window).width();
  const isMobile = /Android|webOS|iPhone|iPad|iPod|BlackBerry/i.test(navigator.userAgent) ? true : width < 640;
  return isMobile;
}

function virtualTryOn(id){
  	window.location.href = "https://oh-my-eyes-eyewear-stockholm.myshopify.com/pages/virtual-try-on?q="+346400;
}

$('#MainNav__Left').hover(function(){
	const el = $('#MainNav__Right').find('.HorizontalList__Item.is-expanded');
    if(el){
          el.find('.MegaMenu').attr('aria-hidden', true);
      el.find('.DropdownMenu').attr('aria-hidden', true);
          el.removeClass('is-expanded');
      }
}, function(){})

$('#MainNav__Right').hover(function(){
	const el = $('#MainNav__Left').find('.HorizontalList__Item.is-expanded');

    if(el){
    	el.find('.MegaMenu').attr('aria-hidden', true);
      el.find('.DropdownMenu').attr('aria-hidden', true);
        el.removeClass('is-expanded');
    }
}, function(){})


function resizeVideo(){
	const width = $(window).width();
  const height = $(window).height();

  const containerHeight = $("#section-slideshow").height();
  const containerWidth = $("#section-slideshow").width();

  const el = $("#Slideshow__DynamicVideo");
  if(!el.length) return;

  const videoWidth = el.width();

  el.css('transform', `translateX(0px)`);

  el.attr('width', 'auto');
  el.attr('height', '100%');


  if(containerWidth > videoWidth){
    el.attr('height', 'auto');
   	el.attr('width', containerWidth);
  }
  else{
    const containerCenterX = videoWidth/2 - containerWidth/2;
    el.css('transform', `translateX(${-containerCenterX}px)`);


  }


}

$(window).resize(function() {
  //resizeVideo();
  setupGetInspredGrid();
  setProductH();
  setDynamicHeight();
});

$(window).on('load', function(){
	setProductH();
});


$( document ).ready(function() {

  openChat();
  discount();
  toggleSustain();

  scrollToReviews();
setupGetInspredGrid();

  $("#Slideshow__DynamicVideo").attr('height', '100%');

  var video = document.getElementById('Slideshow__DynamicVideo');
  if(video){
    video.addEventListener('loadeddata', function() {
      resizeVideo();
    }, false);
  }

  $("#thumbsTrigger").click(function(){
  	console.log('triggered');

    const el = $('.Product__Gallery');

    if(el.hasClass('is-open')){
       el.removeClass('is-open');
  }else{
                              el.addClass('is-open');
}
  })

  $('.Scrolling__Banner').marquee({
	speed: 50,
	gap: 50,
	delayBeforeStart: 0,
	direction: 'left',
	duplicated: true,
    startVisible: true
});


 $('.ProductItem__Wrapper').hover( function() {
   console.log('toggle');
   $(this).find(".product-item__details").toggleClass('toggle_visibility');
 });

   $('.ProductItem__Wrapper').hover( function() {
   $(this).find(".collection_add").toggleClass('toggle_visibility');
 });

  setDynamicHeight();

  $(".Product__Slideshow_slick").slick({
    slidesToShow: 1,
        slidesToScroll: 1,
        dots: false,
    arrows: false,        
    adaptiveHeight: true,
    	asNavFor: '.slider-nav',
  responsive: [
    {
      breakpoint: 1024,
      settings: {
        slidesToShow: 1,
        slidesToScroll: 1,
        infinite: true,
        dots: false
      }
    },
    {
      breakpoint: 768,
      settings: {
        slidesToShow: 1,
        slidesToScroll: 1,
         dots: true,
        autoplay: true
      }
    },
    {
      breakpoint: 480,
      settings: {
        slidesToShow: 1,
        slidesToScroll: 1,
         dots: true,
        autoplay: true
      }
    }
    // You can unslick at a given breakpoint now by adding:
    // settings: "unslick"
    // instead of a settings object
  ]
      });
  
$('.slider-nav').slick({
  slidesToShow: 3,
  slidesToScroll: 1,
  vertical: true,
  asNavFor: '.Product__Slideshow_slick',
  dots: false,
  arrows: true,
  adaptiveHeight: true,
  centerMode: false,
  focusOnSelect: true,
  prevArrow:"<button type='button' class='slick-prev pull-left'><svg viewBox='0 0 100 100'><path d='M 20,50 L 60,90 L 60,85 L 25,50  L 60,15 L 60,10 Z' class='arrow'></path></svg></button>",
  nextArrow:"<button type='button' class='slick-next pull-right'><svg viewBox='0 0 100 100'><path d='M 20,50 L 60,90 L 60,85 L 25,50  L 60,15 L 60,10 Z' class='arrow' transform='translate(100, 100) rotate(180)'></path></svg></button>"
});

});




  function setDynamicHeight(){

    var $myDiv = $(".Grid__Cell");
  var $myDiv2 = $(".ProductItem");
    if ( $myDiv.length){
      var height = $(".Grid__Cell").height();

      $(".c_image").css("height", (height*2)-115);
    }


    if ( $myDiv2.length){
      var height = $myDiv2.height();

      $(".c_image").css("height", (height*2)-115);
    }
  }



document.addEventListener('cart:rendered', function(){
  console.log('cart:rendered');
  discount();
});

document.addEventListener('productRecommendations:loaded', function(){
                          const elements = $('.ProductItem__Wrapper');
if(elements.length > 0){
                          $('.ProductItem__Wrapper').hover( function() {
   console.log('1');
   $(this).find(".product-item__details").toggleClass('toggle_visibility');
 });
}

                          });
