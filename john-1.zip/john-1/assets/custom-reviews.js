class CustomReviews{
  static load(){
    console.log('CustomReviews load');
    let productWithReviewsIds = window.customReviews.products ? window.customReviews.products.split(',') : [];
    
    let uniqueProductWithReviewsIds = [];
    $.each(productWithReviewsIds, function(i, el){
        if($.inArray(el, uniqueProductWithReviewsIds) === -1) uniqueProductWithReviewsIds.push(el);
    });

    productWithReviewsIds = uniqueProductWithReviewsIds;
    let productIndex = 0;
    let loads = 0;
    const cascadeLoad = true;
    const REVIEWS_PER_PAGE = 100;

    window.reviewApp = window.reviewApp || {
      paginator: null,
      newlyLoaded: 0,
      onLoad: true,
      selectedPage: 0,
      lastPage: 0,
      globalPage: 1,
      reviewsByPages:{},
      reviewUrl:'https://productreviews.shopifycdn.com/proxy/v4/reviews/',
      reviewStore: window.customReviews.permanent_domain, /* or hard code the myshopify url - eg: freakdesign.myshopify.com */
    };

    window.showReviewsOnPage = function(page, nextLoad = false){
      if(nextLoad && window.reviewApp.newlyLoaded >= REVIEWS_PER_PAGE){

        loads = 0;
        productIndex = 0;
        window.reviewApp.newlyLoaded = 0;
        window.reviewApp.globalPage = window.reviewApp.globalPage +1;
        reviewApp.getReviewsForProduct(productWithReviewsIds[productIndex], window.reviewApp.globalPage);
        return
      }
      else if(nextLoad && window.reviewApp.newlyLoaded < REVIEWS_PER_PAGE){
        window.reviewApp.paginator.setSelectedPage(page-1)
        return;
      }

      var reviewsContainer = document.getElementsByClassName('Custom__Reviews')[0]
      reviewsContainer.innerHTML = '';

      page = page ? page : (window.reviewApp.globalPage -1 )*25; //page;


      const reviews = window.reviewApp.reviewsByPages[page];

      if(Array.isArray(reviews)){
        reviews.forEach(review => {
          reviewsContainer.appendChild(review);
        })
      }
      $('.spr-review').last().addClass('last');
      $('.spr-review-header-title').each(function(n){
           $(`.spr-review-content-body:eq(${n})`).prepend($(this));
      })

      /* Pagination section*/
      if(window.reviewApp.selectedPage != page){
          const prevPage = document.getElementById(`Page${window.reviewApp.selectedPage}`)
          if(prevPage){
            prevPage.classList.remove('active');
          }
      }

      const currentPage = document.getElementById(`Page${page}`);
      currentPage.classList.add('active');
/* WE DONT NEED AUTOSCROLL ON PAGE LOAD -> 2.6.2020 Vedran
      if(!window.reviewApp.onLoad){
        const headerOffset = isMobile() ? 100 : 200;
        $('html, body').stop().animate({
          scrollTop: $("#shopify-product-reviews").offset().top-headerOffset
        }, 500);
        }

*/
      window.reviewApp.onLoad = false;
      window.reviewApp.selectedPage = page;
    }

    const initializeConstData = function(){
        const maxNumberOfPages = window.customReviews.maxPages;

        const mobile = isMobile();
        let reviewsPerPage = 3;
        if(mobile){
            reviewsPerPage = window.customReviews.reviewsPerPageMobile;
        }
        else{
            reviewsPerPage = window.customReviews.reviewsPerPage;
        }

        return {reviewsPerPage, maxNumberOfPages};
    }



    window.reviewLoaded = function(response){
        const {reviewsPerPage, maxNumberOfPages} = initializeConstData();

      /*Create div and find revies*/
      var tmpDiv = document.createElement('div');
      tmpDiv.innerHTML = response.reviews;
      let reviews = tmpDiv.querySelectorAll('.spr-review');

      /*NodeArray to array*/
      reviews = Array.prototype.slice.call(reviews, 0);
      window.reviewApp.newlyLoaded = window.reviewApp.newlyLoaded + reviews.length;

      const add = window.reviewApp.globalPage > 1 ? 1 : 0; 
      const lastPage = loads > 0 ? window.reviewApp.lastPage + 1 : window.reviewApp.lastPage
      reviews.forEach((val, index) => {

        const page = lastPage + Math.floor(index/reviewsPerPage) + add;

        if(!window.reviewApp.reviewsByPages[page]){
            window.reviewApp.reviewsByPages[page] = []
        }

         window.reviewApp.reviewsByPages[page].push(val)

      })


      const pages =  Object.keys(window.reviewApp.reviewsByPages);
      if(pages.length > 0){
        const nextLastPage = pages[pages.length-1]
        window.reviewApp.lastPage = parseInt(nextLastPage);
        
        loads = loads +1;
      }

      if(maxNumberOfPages)
        window.reviewApp.paginator = new Pagination('reviews-pagination', pages, showReviewsOnPage, maxNumberOfPages);
      else
        window.reviewApp.paginator = new Pagination('reviews-pagination', pages, showReviewsOnPage);

      if(cascadeLoad){
        productIndex = productIndex+1;
        const productId = productWithReviewsIds[productIndex]
        if(productId){
          reviewApp.getReviewsForProduct(productId, window.reviewApp.globalPage)
        }else{
            showReviewsOnPage(0);
        }
      }else{
        showReviewsOnPage(0);
      }

      
    };

    reviewApp.getReviewsForProduct = function(productId, page = 1){

        if(typeof productId === 'undefined'){ console.log('id not defined');return }
        var script = document.createElement("script");

        if(document.getElementById('singleReviewData')){
          document.getElementById('singleReviewData').remove(); /* cleanup (optional) */
        }

        script.id = 'singleReviewData';
        script.async = true;
        script.src = [window.reviewApp.reviewUrl,'product?callback=reviewLoaded&shop=',window.reviewApp.reviewStore,'&product_id=',productId, `&page=${page}`].join('');
        console.log(script.src);
      document.body.appendChild(script);

    };

    if(Array.isArray(productWithReviewsIds) && productWithReviewsIds.length > 0){
        reviewApp.getReviewsForProduct(productWithReviewsIds[productIndex])
    }

  }
}