<script>
  $(document).ready(function(){
    $('.read_more_less').on('click', function(e){
      e.preventDefault();
      if($('.product-description-full:visible')[0]){
        $('.product-description-full').fadeOut(function(){ 
          $('.product-description-short').fadeIn();
        });
      }else{
        $('.product-description-short').fadeOut(function(){ 
          $('.product-description-full').fadeIn();
        });
      }
    });
  });
</script>