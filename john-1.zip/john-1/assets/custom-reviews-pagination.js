function showReviews(obj, index, nextLoad){
  obj.selectedPage = index;
  obj.showReviewsOnPage(index, nextLoad);
}

class Pagination{
    constructor(id, pages, showReviewsOnPage, maxpages = 5){
      console.log('CustomReviews Pagination constructor');
      
      this.selectedPage = 0;
      this.pageElements = []
      this.showReviewsOnPage = showReviewsOnPage;
      this.maxPages = maxpages;
        this.pagination = document.getElementById('reviews-pagination')
        
        this.pagination.innerHTML = '';

        this.totalPages = pages.length;
        this.minorPage = 0;
        this.majorPage = maxpages-1;
      
        if(this.totalPages > 1){
          this.addBackButton();
        }

        if(Array.isArray(pages) && pages.length > 0){
            pages.forEach((page, i) => {
              const element = this.addPage(parseInt(page))
                this.pageElements.push(element);
              
              if(i < maxpages){
              	this.pagination.appendChild(element);
              }
            })
        }
             
      if(this.totalPages > 1){
        this.addNextButton();
      }
      
      //messy
      if(window.reviewApp.globalPage > 1){
      	const page = (window.reviewApp.globalPage -1 )*25;
        
        this.generateNextPageElements(this, page);
      }
    }
  
  generatePreviousPageElements(obj, from){
 	const temp = from - (obj.maxPages-1);
    const to = temp + obj.maxPages;
    from = temp
    for(let i = from, j = 1; i < to; i++, j++){
    	const element = this.pageElements[i];
      
      if(j <= this.maxPages){
        if(element){
          if(obj.pagination.children[j])
          	$(obj.pagination.children[j]).replaceWith(element);
          else
            obj.pagination.appendChild(obj.addPage(j-1));
        }
      }
      	
    }
    
    if(!obj.pagination.children[this.maxPages+1]){
    	obj.addNextButton();
    }
    
    obj.minorPage = from;
    obj.majorPage = to;
    showReviews(obj, to-1)
  }
  
  generateNextPageElements(obj, from){
    let lastPage = 0;
    let lastIndex = 0;
    
    const to = from + obj.maxPages;
    for(let i = from, j = 1; i < to; i++, j++){
    	const element = this.pageElements[i];
      
      if(j <= this.maxPages){
        if(element){
          lastPage = i;
          lastIndex = j;
          $(obj.pagination.children[j]).replaceWith(element);
        }else{
          $(obj.pagination.children[lastIndex+1]).remove();
        }
      }
      	
    }
    
    obj.minorPage = from;
    obj.majorPage = lastPage;
    
    
    showReviews(obj, from)
  }
 
    
    addPage(index){
        let child = document.createElement('a');
        child.setAttribute('id', `Page${index}`);
        child.setAttribute('class', 'Pagination__Selector');
        child.innerHTML = index+1;
        
        child.addEventListener('click', () => showReviews(this, index));
      
      
      return child;
    }
  
  backEventFunction(obj){
    let page = obj.selectedPage - 1;
    page = page <= 0 ? 0 : page;
    
    if(page < obj.minorPage){
      obj.generatePreviousPageElements(obj, page);
    }
    else{
    	showReviews(obj, page)
    }
  }
  
    nextEventFunction(obj){
      let page = window.reviewApp.selectedPage + 1;
      if(page === obj.totalPages){
        showReviews(obj, page, true)
        return;
      }
      
      if(page >= obj.minorPage + obj.maxPages && page < obj.totalPages){
      	obj.generateNextPageElements(obj, page)
      }
      else{
        page = page == obj.totalPages ? obj.totalPages -1 : page;
        showReviews(obj, page)
      }
        
    }
  
  setSelectedPage(page){
  	this.selectedPage = page;
  }
  

    addBackButton(){
      console.log('generate Back');
        let back = document.createElement('a');
        back.setAttribute('id', `Back`);
        back.setAttribute('class', 'Pagination__Selector');
        back.innerHTML = '&lt;';
      
        back.addEventListener('click', () => this.backEventFunction(this));
        
        this.pagination.appendChild(back);
    }

    addNextButton(){
      console.log('generate Next');
        let next = document.createElement('a');
        next.setAttribute('id', `Next`);
        next.setAttribute('class', 'Pagination__Selector');
        next.innerHTML = '&gt;';
      
        next.addEventListener('click', () => this.nextEventFunction(this));
        this.pagination.appendChild(next);
    }
}