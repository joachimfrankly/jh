function filterCollectionBy(type){

  $('.Button__SortCollection').removeClass('is-active');
  $('.Linklist__SortCollection').removeClass('is-selected');
  
  $(`#SortButton--${type}`).addClass('is-active');
  $(`#Linklist__Item--${type}`).addClass('is-selected');

  
  const sortBy = location.search.includes('sort_by=')
        
  if(sortBy){
  	location.search = location.search.replace(/sort_by=[^&$]*/i, `sort_by=${type}`);
  }
  else{
  	location.search = location.search.concat(`sort_by=${type}`)
  }
 
}

function closeCollectionFilterDrawer(){
  const drawerElement = $('#collection-filter-drawer');
  if(drawerElement){
    drawerElement.attr('aria-hidden', 'true');
  }
}

function openCollectionFilterDrawer(){
  var openDropdown = isMobile();
  var openDrawer =  $(window).width() > 640 && $(window).width() < 1000 ? true : false;
  const el = $('#collection-filter-drawer');
 
  console.log(openDropdown, openDrawer);
  if(openDropdown || openDrawer){
    if( el.attr('aria-hidden')){
        el.attr('aria-hidden', false);
      }
      else{
        el.attr('aria-hidden', true);
      }
  }
  else{    
    $("#Filter__Sidebar").toggleClass("is-active");

  }
}

$(document).ready(function(){
  $('#Button__Filter').on('click', function(){
    openCollectionFilterDrawer();
  })
})