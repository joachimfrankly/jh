document.addEventListener('Cart:rendered', function(data){
  
  console.log('cart:rendered');

});

